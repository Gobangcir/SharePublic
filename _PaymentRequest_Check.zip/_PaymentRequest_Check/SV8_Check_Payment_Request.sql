--truncate table ztemp_ag_cekdup

select * from viewonly.ztemp_ag_cekdup

--commit

select msisdn, bank, count(*) 
from viewonly.ztemp_ag_cekdup
having count(*) > 1
group by msisdn, bank 
order by 2 desc


select a.service_name, b.invoice_id, b.current_due, c.payment_id, c.effective_start_date
from ops$svprod.service_history partition (SERVICE_HISTORY_P000_56) a, ops$svprod.invoice b, ops$svprod.invoice_history c 
where a.customer_node_id = b.customer_node_id 
and b.invoice_id = c.invoice_id
and a.service_name in (select msisdn from  viewonly.ztemp_ag_cekdup)
and sysdate between a.effective_start_date and a.effective_end_date
and a.service_status_code <> 9
--and b.issue_date >= to_date('02012018','ddmmyyyy')
and b.invoice_type_id = '30000040'
and b.bill_run_id in (
select  substr(c.output_text,28,9)
from ops$svprod.schedule a, ops$svprod.TASK_QUEUE b, ops$svprod.TASK_QUEUE_RESULT c,  ops$svprod.SCHEDULE_TYPE d, ops$svprod.reference_code e 
where a.schedule_id = b.schedule_id 
and b.task_queue_id = c.task_queue_id
and a.schedule_type_id = d.schedule_type_id
and b.task_status_code = e.reference_code
and a.instance_name = 'SVPRD05B'
and a.schedule_name in ('BR-02','BR-09','BR-16','BR-23')
and c.output_text like '%Bill run%'
and d.schedule_type_id = '106'
--AND b.scheduled_start_date BETWEEN TO_DATE('02/03/2018 00:00:00','DD/MM/YYYY HH24:MI:SS') and TO_DATE('24/08/2018 23:59:59','DD/MM/YYYY HH24:MI:SS')
and b.scheduled_start_date >= sysdate -30
and e.reference_type_id = '585'
)
and c.payment_id is not null
and c.current_due = 0


select a.service_name, d.bank
from ops$svprod.service_history partition (SERVICE_HISTORY_P000_56) a, ops$svprod.invoice b, ops$svprod.invoice_history c, viewonly.ztemp_ag_cekdup d 
where a.customer_node_id = b.customer_node_id 
and b.invoice_id = c.invoice_id
and a.service_name = d.msisdn
and sysdate between a.effective_start_date and a.effective_end_date
and a.service_status_code <> 9
--and b.issue_date >= to_date('02012018','ddmmyyyy')
and b.invoice_type_id = '30000040'
and b.bill_run_id in (
select  substr(c.output_text,28,9)
from ops$svprod.schedule a, ops$svprod.TASK_QUEUE b, ops$svprod.TASK_QUEUE_RESULT c,  ops$svprod.SCHEDULE_TYPE d, ops$svprod.reference_code e 
where a.schedule_id = b.schedule_id 
and b.task_queue_id = c.task_queue_id
and a.schedule_type_id = d.schedule_type_id
and b.task_status_code = e.reference_code
and a.instance_name = 'SVPRD05B'
and a.schedule_name in ('BR-02','BR-09','BR-16','BR-23')
and c.output_text like '%Bill run%'
and d.schedule_type_id = '106'
--AND b.scheduled_start_date BETWEEN TO_DATE('02/03/2018 00:00:00','DD/MM/YYYY HH24:MI:SS') and TO_DATE('24/08/2018 23:59:59','DD/MM/YYYY HH24:MI:SS')
and b.scheduled_start_date >= sysdate -30
and e.reference_type_id = '585'
)
and c.payment_id is not null
and c.current_due = 0




